package com.uca.gui;

public class PokemonPexingGUI {

    public static void pexer(Integer userId, Integer userId2, Integer pokemonId) {

    }
}
