package com.uca.gui;

public class MarketGUI {
    public static String displayMarket() {
        return "";
    }

    public static String displayMarketAdd() {
        return "";
    }

    public static boolean addExchange(Integer userId, Integer idPokemonExchange, Integer idPokemonRequire) {
        return true;
    }

    public static void exchange(Integer userId, Integer userId2, Integer pokemon1, Integer pokemon2) {

    }
}
