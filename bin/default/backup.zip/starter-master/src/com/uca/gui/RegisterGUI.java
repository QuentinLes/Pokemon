package com.uca.gui;

public class RegisterGUI {

    public static String displayRegister() {
        return "";
    }
}
