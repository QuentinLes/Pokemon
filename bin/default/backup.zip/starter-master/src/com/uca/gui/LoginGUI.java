package com.uca.gui;

public class LoginGUI {

    public static String displayLogin() {
        return "";
    }

    public static Integer processLogin(String userName, String password) {
        return 0;
    }
}
