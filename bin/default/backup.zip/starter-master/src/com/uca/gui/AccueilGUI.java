package src.com.uca.gui;

public class AccueilGUI {
    public static String display()
    {
        return "test";
    }
}
